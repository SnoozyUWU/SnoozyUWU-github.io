#!/bin/bash

# Vérifier le nombre d'arguments
if [ $# -ne 1 ]; then
    echo "Utilisation: $0 [--major | --minor | --build] "
    exit 1
fi

# Vérifier l'option passée
case "$1" in
    --major)
        awk -F. '{printf("%d:%s:%s\n", $1+1, 0, 0)}' "version.config" > "version.tmp" && mv "version.tmp" "version.config"
        ;;
    --minor)
        awk -F. '{printf("%s:%d:%s\n", $1, $2+1, 0)}' "version.config" > "version.tmp" && mv "version.tmp" "version.config"
        ;;
    --build)
        awk -F. '{printf("%s:%s:%d\n", $1, $2, $3+1)}' "version.config" > "version.tmp" && mv "version.tmp" "version.config"
        ;;
    *)
        echo "Utilisation: $0 [--major | --minor | --build]"
        exit 1
        ;;
esac
