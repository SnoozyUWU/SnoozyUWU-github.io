<?php
# Markdown vers HTML

# Recuperation du contenu du fichier
$markdown = file_get_contents('doc.md');

# Lecture ligne par ligne
$lines = explode("\n", $markdown);

# Parcours des lignes et remplacement des balises titres, paragraphes, liens et lignes vides
foreach ($lines as &$line) { # le & permet de créer une référence à la valeur de $line dans le tableau $lines (sinon on ne peut pas modifier la valeur de $line)
    
    # Detection des titres
    if (preg_match('/^#/', $line)) {
        $line = preg_replace('/^# (.*)$/', '<h1>$1</h1>', $line); # On remplace toutes les lignes commencant par # par <h1>...</h1>
    }
    if (preg_match('/^##/', $line)) {
        $line = preg_replace('/^## (.*)$/', '<h2>$1</h2>', $line); # On remplace toutes les lignes commencant par ## par <h2>...</h2>
    }
    if (preg_match('/^###/', $line)) {
        $line = preg_replace('/^### (.*)$/', '<h3>$1</h3>', $line); # On remplace toutes les lignes commencant par ### par <h3>...</h3>
    }
    if (preg_match('/^####/', $line)) {
        $line = preg_replace('/^#### (.*)$/', '<h4>$1</h4>', $line); # On remplace toutes les lignes commencant par #### par <h4>...</h4>
    }

    # Detection des paragraphes
    # si la ligne commence par un charactere (lettre, chiffre, etc) alors c'est un paragraphe
    if (preg_match('/^[a-zA-Z0-9]/', $line)) {
        $line = preg_replace('/^$/', '<p>$1</p>', $line); # On remplace le contenu de la ligne par <p>...</p>
    }

    # Detection des liens
    if (preg_match('/\[(.*)\]\((.*)\)/', $line)) {  # on detecte "[...](...)" avec les parenthèses qui contiennent n'importe quoi
        $line = preg_replace('/\[(.*)\]\((.*)\)/', '<a href="$2">$1</a>', $line); # On remplace "[...](...)" par "<a href="...">...</a>" (le $1 correspond au contenu de la première parenthèse, le $2 au contenu de la deuxième parenthèse)
    }
    
    # Detection des lignes vides
    if (preg_match('/$/', $line)) {
        $line = preg_replace('/^$/', '<br><br>', $line); # On remplace le contenu de la ligne par <br><br>
    }
    # si la ligne contient seulement un ou plusieurs espaces, alors c'est une ligne vide
    if (preg_match('/^\s+$/', $line)) {
        $line = preg_replace('/^\s+$/', '<br><br>', $line); # On remplace le contenu de la ligne par <br><br>
    }
}


# Remplacement des balises de code inline et de code block
$code = false; # variable pour savoir si on est dans un bloc de code ou non

foreach ($lines as &$line) {
    # detection des balises ``` pour le code block
    if (preg_match('/```/', $line)) {
        if ($code == false) {
            $line = preg_replace('/```/', '<code>', $line); # On remplace "```" par "<code>" la première fois
            $code = true;
        } else {
            $line = preg_replace('/```/', '</code>', $line); # On remplace "```" par "</code>" la deuxième fois
            $code = false;
        }
    # detection des balises ` pour le code inline
    } elseif (preg_match('/`/', $line)) {
        if ($code == false) {
            $line = preg_replace('/`/', '<code>', $line); # On remplace "`" par "<code>" la première fois
            $code = true;
        } else {
            $line = preg_replace('/`/', '</code>', $line); # On remplace "`" par "</code>" la deuxième fois
            $code = false;
        }
    }
}

# Remplacement des balises de tableaux
$tableau = false; # variable pour savoir si on est dans un tableau ou non
$ligneTableau = 1; # variable pour savoir dans quelle ligne du tableau on est
foreach ($lines as &$line) {

    # detection des balises | pour les tableaux
    if ($tableau == false) { 
        if (preg_match('/^\|/', $line) && $ligneTableau == 1) { 
            $tableau = true;
            $ligneTableau++;
            $line = preg_replace('/^\|(.*)$/', '<table><tr><th>$1', $line); # On remplace "|" par les balises de début de tableau

            # parcours de chaque caractère de la ligne a la recherche de | pour les remplacer par </th><th>
            for ($i = 0; $i < strlen($line); $i++) {
                if ($line[$i] == '|') {
                    $line = substr($line, 0, $i) . '</th><th>' . substr($line, $i + 1); # on remplace le | par </th><th>
                }
            }
            # on retire le dernier <th> et on le remplace par </tr>
            $line = substr($line, 0, strlen($line) - 5) . '</tr>'; # 0 = debut de la chaine, strlen($line)-5 = on retire les 5 derniers caractères de la chaine
        }
    }
    else{
        # detection de la deuxieme ligne contenant des | qui sert a donner le nombre de colonnes
        if ($ligneTableau == 2) {
            $ligneTableau++;
            if (preg_match('/^\|/', $line)){
                # on supprime la ligne
                $line = '';

            }
            else {
                $tableau = false;
                $ligneTableau = 1;
            }
        }
        if ($ligneTableau > 2){
            $ligneTableau++;
            if (preg_match('/^\|/', $line)){
                $line = preg_replace('/^\|(.*)$/', '<tr><td>$1', $line);
                # parcours de chaque caractère de la ligne a la recherche de | pour les remplacer par </td><td>
                for ($i = 0; $i < strlen($line); $i++) {
                    if ($line[$i] == '|') {
                        $line = substr($line, 0, $i) . '</td><td>' . substr($line, $i + 1); # on remplace le | par </td><td>
                    }
                }
                # on retire le dernier <td> et on le remplace par </tr>
                $line = substr($line, 0, strlen($line) - 5) . '</tr>'; # 0 = debut de la chaine, strlen($line)-5 = on retire les 5 derniers caractères de la chaine
            }
        }
    }
}

$listeOuverte = false; # variable pour savoir si la liste a deja commencé ou non
for($ligne = 0; $ligne < count($lines)-1; $ligne++){ # on parcourt toutes les lignes sauf la dernière
    if (preg_match('/^-\s/', $lines[$ligne]) && $listeOuverte == false) { # si la ligne commence par un tiret et que la liste n'est pas encore ouverte
        $lines[$ligne] = preg_replace('/^-\s(.*)$/', '<ul><li>$1</li>', $lines[$ligne]);
        $listeOuverte = true;
    }
    elseif(preg_match('/^\s-\s(.*)$/', $lines[$ligne])){ # detecte si la ligne est un espace suivi d'un tiret
        $lines[$ligne] = preg_replace('/^\s-\s(.*)$/', '<ul><li>$1</li></ul>', $lines[$ligne]);
    }
    elseif(preg_match('/^\t-\s(.*)$/', $lines[$ligne])){ # detecte si la ligne est une tabulation suivi d'un tiret
        $lines[$ligne] = preg_replace('/^\t-(.*)$/', '<ul><li>$1</li></ul>', $lines[$ligne]);
    }
    elseif(preg_match('/^-\s/', $lines[$ligne]) && $listeOuverte == true){ # si la ligne commence par un tiret et que la liste est déjà ouverte
        $lines[$ligne] = preg_replace('/^-\s(.*)$/', '<li>$1</li>', $lines[$ligne]); # on remplace le tiret par <li></li>
    }
    #si on retrouve une ligne autre qu'un tiret on ferme la balise ul
    elseif(preg_match('/^[^-\s]/', $lines[$ligne]) && $listeOuverte == true){ 
        $lines[$ligne-1] = preg_replace('/(.*)$/', '$1</ul>', $lines[$ligne-1]); 
        $listeOuverte = false;
    }
}

# si la dernière ligne du fichier est un tiret on crée une liste qu'on ferme directement après (comme on a parcouru toutes les lignes sauf la dernière)
if(preg_match('/^-\s/', $lines[count($lines)-1])){
    $lines[count($lines)-1] = preg_replace('/^-\s(.*)$/', '<ul><li>$1</li></ul>', $lines[count($lines)-1]);
}


# Ajout des balises html et du contenu dans le fichier index.html
$debut ='<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="author" content="Les Rickrolliens">
    <title>Markdown2HTML</title>
</head>
<body>

<main>';
$contenu = implode("\n", $lines);
$fin ="</main>

</body>
</html>";

# récupération du fichier de versions version.config

$version = file_get_contents('version.config');


# création du fichier doc-user-$version.html



file_put_contents('doc-user-'.$version.'.html', $debut);
file_put_contents('doc-user-'.$version.'.html', $contenu, FILE_APPEND);
file_put_contents('doc-user-'.$version.'.html', $fin, FILE_APPEND);

echo "Le fichier doc-user-$version.html a été créé avec succès !";
?>