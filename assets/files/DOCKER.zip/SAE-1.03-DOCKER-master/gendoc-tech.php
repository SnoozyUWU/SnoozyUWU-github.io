<?php
    //main

    $listeFichier = ouvreFichier(__DIR__);
    creeLaPage();

    $cheminVersion = __DIR__ . '/version.config';
    $version = file_get_contents($cheminVersion);
    echo "<h2>Version: ".$version."<h2>";

    foreach ($listeFichier as $fichier) {
        $bordureConstantes = true;
        $bordureTypeDef = true;
        $bordureVariablesGlobales = true;
        $bordureStruct = true;
        $bordureFonctions = true;
        //j'appelle résuméProgramme pour afficher le résumé et commencer a partir de sa fin
        for ($i=resumeProgramme($fichier); $i < count($fichier); $i++) { 
            // je commence par check les define
            if ( contiens("#define",$fichier[$i])) {
                // en gros es ce que j'ai besoin d'afficher le titre?
                if ($bordureConstantes){
                    echo "<hr><h2> Defines: </h2>";
                    $bordureConstantes = false;
                }
                lesDefine($fichier,$i);
            }
            //les const n'étant pas mentionnées dans le sujet elle ne seront pas prises en compte
            // je m'occupe des typedef
            if ( contiens("typedef",$fichier[$i]) && !contiens("struct",$fichier[$i])) {
                // en gros es ce que j'ai besoin d'afficher le titre?
                if ($bordureTypeDef){
                    echo "<hr><h2> Types Spéciaux </h2>";
                    $bordureTypeDef = false;
                }
                $j = $i;
                while (!contiens("/**",$fichier[$j-1]) && $j >0 ) {
                    $j--;
                }
                defType($fichier,$j);
            }
            // je m'ocupe des structures
            if ( contiens("typedef struct",$fichier[$i])) {
                // en gros es ce que j'ai besoin d'afficher le titre?
                if ($bordureStruct){
                    echo "<hr><h2> Structures </h2>";
                    $bordureStruct = false;
                }
                lesStructures($fichier,$i);
                echo "</br>";
            }
            // je m'occupe des variables globales
            if ( contiens("\detail",$fichier[$i]) && contiens("/**",$fichier[$i-1])) {
                // en gros es ce que j'ai besoin d'afficher le titre?
                if ($bordureVariablesGlobales){
                    echo "<hr><h2> Variables Globales </h2>";
                    $bordureVariablesGlobales = false;
                }
                $j = $i;
                while (!contiens("/**",$fichier[$j-1]) && $j >0 ) {
                    $j--;
                }
                varGlob($fichier,$j);
            }
            // je m'occupe des fonctions/procédures
            if ( contiens("\brief",$fichier[$i]) && contiens("/**",$fichier[$i-1])) {
                // en gros es ce que j'ai besoin d'afficher le titre?
                if ($bordureFonctions){
                    echo "<hr><h2>Fonctions & Procédures </h2>";
                    $bordureFonctions = false;
                }
                $j = $i;
                while (!contiens("/**",$fichier[$j-1]) && $j >0 ) {
                    $j--;
                }
                lesFonctions($fichier,$j);
            }
        }
    }
    fermeLaPage();
    //finMain

    function ouvreFichier($repertoire){
        $files = glob($repertoire . '/*.c');
        // Vérifie si des fichiers .c ont été trouvés
        if ($files !== false) {
            $iFichier = 0;
            // Parcourt chaque fichier .c et le met dans un tableau
            foreach ($files as $fichier) {
                // Ouvre le fichier en lecture
                $liste[$iFichier] = file($fichier);
                $iFichier++;
            }
        } else {
            echo "Aucun fichier .c trouvé dans le répertoire.\n";
        }
        return $liste;
    }

    function resumeProgramme($fic){
        $i = 1;
        $lignesTronque = '';
        while (contiens('*',$fic[$i]) && !contiens('*/',$fic[$i])){
            $lignesTronque = $lignesTronque. substr($fic[$i], 2);
            $i++;
        } 
        $lignesTronque = str_replace(array("\r", "\n", "\r\n"),'',$lignesTronque); 
        echo "<hr><h2>En-tête de code</h2></br><p>".$lignesTronque."</p>";
        return $i;
    }

    function lesDefine($fic,$ligneDebut){
        $nomConstante = "";
        $ligneTronque = str_replace("#define",'',$fic[$ligneDebut]);
        $i = 0 ;
        $espaces = 0;
        $aRetirer ="";
        while ($ligneTronque[$i] != '/') {
            if ($ligneTronque[$i] == ' ') {
                $espaces++;
            }
            if ($espaces == 2 && $ligneTronque[$i] == ' ' ) {
                $nomConstante = $nomConstante.' = ';
            }else{
               $nomConstante = $nomConstante.$ligneTronque[$i];
            }
            $aRetirer = $aRetirer . $ligneTronque[$i];
            $i++;
        }
        // $nomConstante = str_replace(' ','',$nomConstante);
        $ligneTronque = str_replace(array("/**","*/",$aRetirer),'',$ligneTronque);
        echo "<h3>Constante ".$nomConstante."</h3><p>".$ligneTronque."</p>";
    }

    function defType($fic,$ligneDebut){
        $i = $ligneDebut;
        $lignesTronque = '';
        while ( !contiens('*/',$fic[$i])){
            if (contiens('\typedef',$fic[$i])) {
                // str_replace(array("\typedef","*"),'',$fic[$i]) ne marchait pas donc je retire arbitrairement les 11 premiers charactères
                echo "</br><h3>Type ".substr($fic[$i],11) .":</h3>";
                $i++;
            }else if (contiens('\detail',$fic[$i])){
                echo "<h4>Résumé:</h4><p>".str_replace(array("\detail","*"),'',$fic[$i])."</p>";
                $i++;
            }else{
                while (!contiens('*/',$fic[$i])){
                    $lignesTronque = $lignesTronque. substr($fic[$i], 3);
                    $i++;
                }
                $lignesTronque = str_replace(array("\r", "\n", "\r\n"),'',$lignesTronque);
                echo "<h4>Détail:</h4><p>".$lignesTronque."</p>";
            }
        }
        echo "<h4>Déclaration:<h4><p>".$fic[$i+1]."</p>";
    }

    function lesStructures($fic,$ligneDebut){
        $i = $ligneDebut;
        while ( !contiens('}',$fic[$i])){
            $i++;
        }
        $parties = explode(';', $fic[$i]);
        $nomStructure = str_replace(array('/**','*/',';','}'),'',$parties[0]);
        $lignesTronque = str_replace(array('/**','*/',';'),'',$parties[1]);
        echo "<h3>Structure ".$nomStructure." :<h3>";
        echo "<h4>Résumé: </h4><p>".$lignesTronque."</p>";

        $j = $ligneDebut+1;
        // je répète jusque'a la fin de la structure
        while ( !contiens('}',$fic[$j])) {
            $parties = explode(';', $fic[$j]); 
            $nomAtribut =str_replace(array('}',";"),'',$parties[0]);
            $commentaireAtribut = str_replace(array('/**','*/',";"),'',$parties[1]);
            //je retire tout ce qui ne doit pas etre dans la description de l'attribut
            echo "<h4>Atribut :".$nomAtribut."</h4><p>  ".$commentaireAtribut."</p>";
            $j++;
        }
    }

    function varGlob($fic,$ligneDebut){
        $i = $ligneDebut;
        $lignesTronque = '';
        while ( !contiens('*/',$fic[$i])){
            if (contiens('\detail',$fic[$i])) {
                // str_replace(array("\typedef","*"),'',$fic[$i]) ne marchait pas donc je retire arbitrairement les 11 premiers charactères
                echo "</br><h3>Variable ".substr($fic[$i],11) .":</h3>";
                $i++;
            }else{
                while (!contiens('*/',$fic[$i])){
                    $lignesTronque = $lignesTronque. substr($fic[$i], 3);
                    $i++;
                }
                $lignesTronque = str_replace(array("\r", "\n", "\r\n"),'',$lignesTronque);
                echo "<h4>Résumé:</h4><p>".$lignesTronque."</p>";
            }
        }
        echo "<h4>Déclaration:<h4><p>".$fic[$i+1]."</p>";
    }

    function lesFonctions($fic,$ligneDebut){
        $i = $ligneDebut;
        $j = $ligneDebut+1 ;
        while ( !contiens("*/",$fic[$j-1])) {
            $j++;            
        }
        $partiesTitre = $fic[$j];
        $partiesTitre = explode(' ',$partiesTitre);
        $partiesTitre = $partiesTitre[1];
        $partiesTitre = explode('(',$partiesTitre);
        $nomFonction = $partiesTitre[0];
        // ne marche que si la déclaration de la fonction est dirrectement après le commentaire sans saut de ligne
        echo "<h3>Fonction ".$nomFonction." : </h3>";

        // je m'occupe de la balise brief
        $partiesBrief = explode("\brief",$fic[$i]);
        echo "<h4>Résumé : </h4><p>".$partiesBrief[1]."</p>";
        $i++;

        // je m'occupe du résumé si il existe
        if (contiens("\detail",$fic[$i])) {
            $partiesDetail = $fic[$i];
            $partiesDetail = explode('detail',$partiesDetail);
            $detail = $partiesDetail[1]."</br>";
            echo "<h4>Détail : </h4>";
            $i++;
            while (!contiens('\param',$fic[$i]) && !contiens('\return',$fic[$i] ) && !contiens('*/',$fic[$i] ) ) {
                $detail = $detail.str_replace('*','',$fic[$i]);
                $detail = $detail."</br>";
                $i++;
            }
            echo "<p>".$detail."</p>";
        }
        
        // je m'occupe des paramètres/return si il y en a
        if (contiens('\return',$fic[$i])) {
            $partiesReturn = $fic[$i];
            //cette ligne sert a retirer ce qu'il ya a avant le return
            $partiesReturn = explode('\return',$partiesReturn);
            // je n'ai pas de bonne séparation pour le return donc: je retire retire ce qu'il y a en type de variable a la ligne complète
            $partiesReturn2 = $partiesReturn[1];
            $partiesReturn = $partiesReturn[1];
            $partiesReturn = explode(' ',$partiesReturn);
            $partiesReturn2 = str_replace($partiesReturn[1],'',$partiesReturn2); 
            echo "<h4>Renvoie :</h4><p>".$partiesReturn[1]." : ".$partiesReturn2." </p>";
            $i++;
        }

        while ( !contiens('*/',$fic[$i]) && contiens('\param',$fic[$i])) {
            // je vais faire exactement pareille que pour les return... 
            $partiesParam = $fic[$i];
            $partiesParam = explode('\param',$partiesParam);
            $partiesParam2 = $partiesParam[1];
            $partiesParam = $partiesParam[1];
            $partiesParam = explode(' ',$partiesParam);
            $partiesParam = $partiesParam[1];
            $partiesParam2 = str_replace($partiesParam,'',$partiesParam2); 
            echo "<h4>Paramètre :</h4><p>".$partiesParam." :".$partiesParam2." </p>";
            $i++;
        }
        echo "</br>";
    }

    function contiens($phrase1,$ligne){
        $trouve = false;
        
        if(strpos($ligne, $phrase1) !== false){
            return true;
        }else{
            return false;
        }
    }

    function creeLaPage(){
        $cssContenu = file_get_contents("exemple.css");
        echo "<!DOCTYPE html>
        <html lang=\"fr\">
        <head>
            <meta charset=\"UTF-8\">
            <title> La documentation de mon code C - SAE 1.03 </title>
            <style>".$cssContenu."</style>
            <link rel=\"preconnect\" href=\"https://fonts.googleapis.com\">
            <link rel=\"preconnect\" href=\"https://fonts.gstatic.com\" crossorigin>
            <link href=\"https://fonts.googleapis.com/css2?family=Lato&display=swap\" rel=\"stylesheet\"> 
        </head>
        <body>
        
            <header>
                <nav>
        
                    <a href=\"DOC_TECHNIQUE.html\">Home</a>
                    <a href=\"DOC_TECHNIQUE_Client.html\">Client</a>
                    <a href=\"DOC_TECHNIQUE_Version.html\">Versions</a>
                    <a href=\"DOC_TECHNIQUE_Date.html\">Dates</a>
                </nav>
            </header>
            <hr>
            <main>\n";
    }
    function fermeLaPage(){
        echo "
            </main>
            <hr>
            <footer>
                <p>Ceci est le pied de page de notre documentation - Copyright (Les élèves de BUT Informatique © 2023)</p>
            </footer>
        </body>
        </html> ";
    }

    function afficheEntete($resume){
        echo "<section>
        <h1> Documentation de notre code C pour la SAE 1.03 </h1>
        <h2>En-tête de code</h2>".$resume."
        <p>Le fichier source contient un programme pour imprimer le calendrier d'une année spécifiée.</p>
        </section>";
    }

?>
