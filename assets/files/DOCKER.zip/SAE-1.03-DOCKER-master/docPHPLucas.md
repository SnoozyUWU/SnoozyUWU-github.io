## Documentation de mon code PHP


```file_put_contents()```

#### Utilisée pour écrire dans un fichier

```$htmlFile```

### Nom du fichier dans lequel on enregistre

```$htmlContent```

### Chaine qui contient le code HTML