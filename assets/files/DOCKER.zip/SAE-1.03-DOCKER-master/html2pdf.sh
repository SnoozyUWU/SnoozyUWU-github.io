#!/bin/bash

# Nom du fichier HTML d'entrée
htmlFile="votre_fichier.html"

# Nom du fichier PDF de sortie
pdfOutputFile="votre_fichier.pdf"

# Commande Docker pour la conversion HTML vers PDF
docker run -v "$(pwd):/data" -i --rm big/papoo/sae103-html2pdf:latest "$htmlFile" "/data/$pdfOutputFile"

# Exécution de la commande dans le terminal
output=$(eval "$commandeDocker")

# Boucle de vérification de conversion
if [ -z "$output" ]; then
    echo "La conversion est terminée"
else
    echo "La conversion a échoué"
fi
