#!/bin/bash

docker volume create sae103

docker image pull bigpapoo/clock  #Execute un conteneur

docker image pull bigpapoo/sae103-html2pdf #Telecharge l'image pour la conversion)

docker container run sae103-html2pdf #Lancer le conteneur pour pouvoir lancer l'image

docker run -d --name sae103-forever -v sae103:/data clock #Lancer le conteneur en mode détaché

# Copie des fichiers .c dans le volume sae103
docker cp *.c sae103-forever:/data/ #Tout les fichiers qui se terminent par un .c
docker cp *.md sae103-forever:/data/ #Tout les fichiers qui se terminent par un .md


php gendo-tech.php #On va chercher la conversion de gendoc-tech

php gendo-user.php #On va chercher la conversion de gendoc-user

docker stop sae103-forever #Fin du conteneur

docker volume rm sae103 #Suppression du volume utiliser
